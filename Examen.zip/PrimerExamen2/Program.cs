﻿using System.Text.RegularExpressions;

namespace PrimerExamen2
{
    internal class Program
    {
        static void Main(string[] args)
        {
           //  Empleado empleado = new Empleado("12345678F");

            Console.WriteLine("Cuantro Empleados? ");
            var numEmpleados = Convert.ToInt32(Console.ReadLine());

            List<Empleado> emple = new List<Empleado>();
          
            while (numEmpleados > 0)

            {
            
                Console.WriteLine("introduce DNI Empleado: ");
                var DNI = Convert.ToString(Console.ReadLine());

                Console.WriteLine("introduce Nombre Empleado: ");
                var Nombre = Convert.ToString(Console.ReadLine());

                Console.WriteLine("introduce SueldoBase Empleado: ");
                var SueldoBase = Convert.ToDecimal(Console.ReadLine());


                Console.WriteLine("introduce PagoHoraExtra Empleado: ");
                var PagoHoraExtra = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("introduce Horas extras al mes Empleado: ");
                var HorasExtrasAlMes = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("introduce IrpfPorcentaje Empleado: ");
                var IrpfPorcentaje = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("introduce si Empleado es casado : ");
                var casado = Convert.ToBoolean(Console.ReadLine());

                Console.WriteLine("introduce NumeroHijo de  Empleado  : ");
                var NumeroHijo = Convert.ToInt32(Console.ReadLine());


                var UnEmpleado = new Empleado(DNI , Nombre , SueldoBase , PagoHoraExtra ,
                    
                    HorasExtrasAlMes , IrpfPorcentaje , casado , NumeroHijo);


                emple.Add(UnEmpleado);


                numEmpleados--;
            }




             var MasCobra = emple.Select(n => n.SueldoBase).Max();

            var MenosCobra = emple.Select(n => n.SueldoBase).Min();

            var NumeroHijos = emple.Select(n => n).Where(n => n.NumeroHijo > 0);

            var OrdenarDesc = emple.Select(n => n).OrderByDescending(n => n.CalculoSueldoBruto());

            var Ordenar = emple.Select(n => n).OrderBy(n => n.CalculoSueldoBruto());
            //  empleado.ToString();







        }
    }
}