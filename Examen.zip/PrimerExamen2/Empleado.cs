﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PrimerExamen2
{
    //^\s*$\n
    internal class Empleado
    {
        public string DNI { get; set; }
        public string Nombre { get; set; } = "";
        public decimal SueldoBase { get; set; } = 0;
        public decimal PagoHoraExtra { get; set; } = 0;
        public int HorasExtrasAlMes { get; set; } = 0;
        public double IrpfPorcentaje { get; set; } = 0;
        public bool Casado { get; set; } = false;
        public int NumeroHijo { get; set; } = 0;

        public string Eldni
        {
            get { return DNI; }

            set
            {

                string patron = @"[1-9]{8}[A-Z]{1}";

                Regex regex = new Regex(patron);

                if (regex.IsMatch(value))
                {
                    DNI = value;

                }

                else
                {
                    throw new ArgumentException("DNI no es correcto");
                }

            }

        }

        public Empleado(string dni)
        {
            Eldni = dni;
        }

        public Empleado(string dni, string nombre, decimal sueldoBase, decimal pagoHoraExtra
             , int horasExtrasAlMes, double irpfPorcentaje, bool casado, int numeroHijo

            )
        {
            Eldni = dni;
            Nombre = nombre;
            SueldoBase = sueldoBase;
            PagoHoraExtra = pagoHoraExtra;
            HorasExtrasAlMes = horasExtrasAlMes;
            IrpfPorcentaje = irpfPorcentaje;
            Casado = casado;
            NumeroHijo = numeroHijo;
        }

        public decimal CalculoComplemento()
        {

            return HorasExtrasAlMes * PagoHoraExtra;

        }

        public decimal CalculoSueldoBruto()
        {
            return CalculoComplemento() + SueldoBase;
        }


        public double RetencionesIrpf()
        {

            if (Casado)
            {
                IrpfPorcentaje += 2.0;

            }


            if (NumeroHijo > 0)

            {

                IrpfPorcentaje += NumeroHijo;
            }

         //   SueldoNeto = Convert.ToDecimal(Convert.ToDouble(CalculoSueldoBruto()) - (Convert.ToDouble(CalculoSueldoBruto()) * (IrpfPorcentaje / 100)));
            return IrpfPorcentaje;

        }

        public void  ToString()
        {
            Console.WriteLine($"Nombre: {Nombre} sueldo neto: {SueldoBase - Convert.ToDecimal(Convert.ToDouble(CalculoSueldoBruto()) - (Convert.ToDouble(CalculoSueldoBruto()) * (IrpfPorcentaje / 100)))} ");

        }







    }
}
