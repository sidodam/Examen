﻿namespace PrimerExamen
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Agregar(5);

        }

        public static void Agregar(int input)
        {

            int valor = 0;

            Console.WriteLine("introduce un valor: ");
            // var input = Convert.ToInt32(Console.ReadLine());

            for (int i = valor; i < input + 1; i++)
            {

                Console.WriteLine(i);

            }
        }
    }
}